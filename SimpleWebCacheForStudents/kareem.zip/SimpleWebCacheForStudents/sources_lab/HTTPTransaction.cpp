#include "HTTPTransaction.h"
#include "HTTPGETRequest.h"
#include "HTTPNotAcceptableExceptionHandler.h"
#include "HTTPMethodNotAllowedExceptionHandler.h"

HTTPTransaction::HTTPTransaction (TCPSocket * p_tcpSocket,HTTPServiceManager * p_httpServiceManager,HTTPRequestManager * p_httpRequestManager)
{
    httpServiceManager = p_httpServiceManager;
    tcpSocket = p_tcpSocket;
    httpRequestManager = p_httpRequestManager;
};

HTTPRequest * HTTPTransaction::fetchHTTPRequest ()
{
    char buffer[100];
    memset (buffer,0,100);
    int read  = 0 ;
    for ( int i = 0 ; i < 10 && read == 0; i ++)
        read = tcpSocket->readFromSocket(buffer,99); 
    if ( read == 0) return NULL;
    stringstream iss(buffer); 
    string method="";
    getline(iss,method,' ');
   HTTPRequest * httpRequest = httpRequestManager->getService(tcpSocket,method);    
    if (httpRequest != NULL ) httpRequest->readAndParse(buffer);
    return httpRequest; 
}
void HTTPTransaction::process()
{
    HTTPRequest * httpRequest;
    try{ 
        httpRequest= fetchHTTPRequest (); 
        if ( httpRequest != NULL)
        {
            HTTPService * s  =httpServiceManager->getService(httpRequest->getResource());
            s->execute(httpRequest,tcpSocket);
            delete (httpRequest);
        }
        tcpSocket->shutDown();
    }
    catch (HTTPNotAcceptableExceptionHandler httpNotAcceptableExceptionHandler )
    { 
        httpNotAcceptableExceptionHandler.handle(tcpSocket);
        delete (httpRequest);
        tcpSocket->shutDown();
    }
    catch (HTTPMethodNotAllowedExceptionHandler httpMethodNotAllowedExceptionHandler )
    { 
        httpMethodNotAllowedExceptionHandler.handle(tcpSocket);
        tcpSocket->shutDown();
    }
    
}
void HTTPTransaction::threadMainBody ()
{
    process();
}
void HTTPTransaction::startHTTPTransaction(HTTPTransaction * me)
{
	me->threadMainBody();
}
void HTTPTransaction::setThread(std::thread * p_th)
{
	th = p_th;
	th->detach();
}
bool HTTPTransaction::isRunning()
{
	return !th->joinable();
}

void HTTPTransaction::waitForRunToFinish()
{
	th->join();
}
HTTPTransaction::~HTTPTransaction()
{
    delete (tcpSocket); 
}
