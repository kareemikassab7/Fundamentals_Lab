#ifndef HTTPXMLSERVICE_H
#define HTTPXMLSERVICE_H
#include "HTTPService.h"
class HTTPXMLService: public HTTPService
{
    private:
    public:
        HTTPXMLService(FileCache * p_fileCache,bool p_clean_cache = true);
        virtual bool execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket);
        virtual HTTPService * clone ();
        ~HTTPXMLService();
};

#endif 
