#include "HTTPPOSTRequest.h" 

HTTPPOSTRequest::HTTPPOSTRequest(TCPSocket * p_tcpSocket): HTTPRequest(p_tcpSocket) {}//constructor

void HTTPPOSTRequest::readAndParse(string initial_header)//prsing function
{
    HTTPRequest::readAndParse(initial_header); //parse intial header
    long stdin_size = atol(header["content-length"].c_str());
    
    for ( ;body.length() < stdin_size; )
    {
        char buffer[1024]; //create buffer
        memset ( buffer,0,1024); //intialize to zero
        tcpSocket->readFromSocket(buffer,1023); //read from socket in the buffer
        body +=buffer;//add buffer to body
    }
}//cloner function
HTTPRequest * HTTPPOSTRequest::clone (TCPSocket * p_tcpSocket)
{
    return new HTTPPOSTRequest(p_tcpSocket);// return pointer to object
}
HTTPPOSTRequest::~HTTPPOSTRequest()//destructor
{
}
