#ifndef HTTPJAVASERVICE_H
#define HTTPJAVASERVICE_H
#include "HTTPService.h"
class HTTPJAVAService: public HTTPService
{
    private:
    public:
        HTTPJAVAService(FileCache * p_fileCache,bool p_clean_cache = true);
        virtual bool execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket);
        virtual HTTPService * clone ();
        ~HTTPJAVAService();
};

#endif 
