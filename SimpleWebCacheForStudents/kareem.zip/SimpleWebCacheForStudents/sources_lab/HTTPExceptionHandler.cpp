#include "HTTPExceptionHandler.h"

HTTPExceptionHandler::HTTPExceptionHandler(){}//constructor

HTTPExceptionHandler::~HTTPExceptionHandler() {} //destructor
