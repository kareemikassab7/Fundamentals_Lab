#include "HTTPFormService.h"
#include "HTTPResponseHeader.h"
#include "HTTPNotFoundExceptionHandler.h"
// An HTTP Service that serves HTML Form posts and parses
string HTTPFORMService::urldecode(string & urlencoded)
{
    string urldecoded=""; // create new string variable
    for ( int i = 0 ;i < urlencoded.length();) //loop number of times equal to length of the string
    { 
        char c = urlencoded[i];// create array of characters
        if (i < urlencoded.length() - 2 && c == '%') { //condition
            char c1 = urlencoded[i + 1]; //set value of c1 index i+1
            char c2 = urlencoded[i + 2];//set value of c1 index i+2
            c1 = tolower(c1);
            c2 = tolower(c2);
            if (isxdigit(c1) && isxdigit(c2)) {
                if (c1 <= '9') c1 = c1 - '0';
                else c1 = c1 - 'a' + 10;
                if (c2 <= '9') c2 = c2 - '0';
                else c2 = c2 - 'a' + 10;
                c = (char) ((16 * c1) + c2);
                if ( c == '\n') urldecoded += "<br/>";
                urldecoded+=c;
                i += 3;//increment i

            } else {
                urldecoded+= c;
                i++;//increment i

            }
        } else {
            if (c == '+') c = ' ';
            urldecoded+= c;
            i++;//increment i
        }        
    }
    return urldecoded;
}
void HTTPFORMService::add_to_form_data(string & form_field)//function to add to the form data
{
  
	string key = form_field.substr(0, form_field.find("="));//cut from start to =
   	string value = form_field.substr(form_field.find("=")+1, form_fieldi.length());//parse from '='+1 to end of string
   	raw_form_data[key]=value;//add coded key and value to raw map
	key=urldecode(key);//decode
	value=urldecode (value);//decode
	form_data[key] = value;//add decoded key and value to form_data map

    	// you need to add code here

}

void HTTPFORMService::parse_data (HTTPRequest * p_httpRequest)
{
    string data  = p_httpRequest->getBody();// get the the body to a string
    stringstream iss(data);//prepare for parsing
    string field = ""; //declare new string
    for (;!iss.eof();)
    {
        getline(iss,field,'&'); //parse until '&'
        field += "&"; // add '&' to string in field
        add_to_form_data(field);//call add_to_form_data function
    }
}

string HTTPFORMService::compose_reply()
{
    string reply = "<html><head><title>Form Engine</title></head><body>";//create the string reply
    reply += "<table width='100%' border='1'>";     // add table width and 

    for_each (raw_form_data.begin(),raw_form_data.end(),[&reply](const std::pair<string,string>& it) -> bool {//lampda function add parts to the reply string
            reply += "<tr><td>";
            reply += std::get<0>(it);
            reply += "</td><td>";
            reply += std::get<1>(it);
            reply += "</td></tr>";
            return true; //return true
    });
    reply += "</table><br/>";
    reply += "<table width='100%' border='1'>"; 
    for_each (form_data.begin(),form_data.end(),[&reply](const std::pair<string,string>& it) -> bool {//lamda function
            reply += "<tr><td>";
            reply += std::get<0>(it);
            reply += "</td><td>";
            reply += std::get<1>(it);
            reply += "</td></tr>";
            return true; 
    });
    reply += "</table>";// add table
    reply += "</body></html>";//add body html
    return reply;

}
HTTPFORMService::HTTPFORMService( )
        :HTTPService(NULL,false) {} 

bool HTTPFORMService::execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket)
{
    parse_data(p_httpRequest);// call parse function
    string reply = compose_reply();//compose reply

    // you need to add code here
	HTTPResponseHeader * httpResponseHeader = new HTTPResponseHeader(p_tcpSocket,"OK",200,"HTTP/1.1");// create new HTTPResponseHeader
        httpResponseHeader->setHeader("Content-Type","text/html");// set header content-Type
        httpResponseHeader->setHeader("Connection","close");//close connectionafter response
        httpResponseHeader->setHeader("Content-Length",to_string(reply.length()));//header:content length

        httpResponseHeader->respond();// call method respond
        p_tcpSocket->writeToSocket(reply.c_str(),reply.length());//send reply to socket
        delete (httpResponseHeader);//delete
        return true;//return
}

HTTPService * HTTPFORMService::clone ()// function to clone new objects of HTTPFORMService
{
    return new HTTPFORMService();  // return pointer to new HTTPFORMService
}
HTTPFORMService::~HTTPFORMService(){}//destructor
