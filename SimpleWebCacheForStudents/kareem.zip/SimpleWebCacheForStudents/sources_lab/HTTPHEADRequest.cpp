#include "HTTPHEADRequest.h"
#include "TCPSocket.h" 
// Constructor:  calling the base class constructor
HTTPHEADRequest::HTTPHEADRequest(TCPSocket * p_tcpSocket): HTTPRequest(p_tcpSocket)
{
}
//parsing intial header
void HTTPPOSTRequest::readAndParse(string initial_header)
{
    HTTPRequest::readAndParse(initial_header);
    long stdin_size = atol(header["content-length"].c_str());

    for ( ;body.length() < stdin_size; )
    {
        char buffer[1024];
        memset ( buffer,0,1024);
        tcpSocket->writeToSocket(buffer,1023);
        body +=buffer;
    }

//cloner function
HTTPRequest * HTTPHEADRequest::clone (TCPSocket * p_tcpSocket)
{
    return new HTTPHEADRequest(p_tcpSocket);// return new HTTPHEADERRequest object
}
HTTPHEADRequest::~HTTPHEADRequest()
{//destructor
}
