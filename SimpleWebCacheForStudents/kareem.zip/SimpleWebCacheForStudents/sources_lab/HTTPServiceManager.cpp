#include "HTTPServiceManager.h"
#include "HTTPNotAcceptableExceptionHandler.h"
#define WEB_CACHE_ROOT  "./www"
using namespace std;
HTTPServiceManager::HTTPServiceManager()
{
    services ["html"] = new HTTPHTMLService(new FileCache(WEB_CACHE_ROOT),true);
services ["pdf"] = new HTTPPDFService(new FileCache(WEB_CACHE_ROOT),true);
services ["jpg"] = new HTTPIMGService(new FileCache(WEB_CACHE_ROOT),true);
services ["jpeg"] = new HTTPIMGService(new FileCache(WEB_CACHE_ROOT),true);
services ["png"] = new HTTPPNGService(new FileCache(WEB_CACHE_ROOT),true);
services ["gif"] = new HTTPGIFService(new FileCache(WEB_CACHE_ROOT),true);
services ["mp4"] = new HTTPVIDService(new FileCache(WEB_CACHE_ROOT),true);
services ["mp3"] = new HTTPAUDService(new FileCache(WEB_CACHE_ROOT),true);
services ["js"] = new HTTPJAVAService (new FileCache(WEB_CACHE_ROOT),true);
services ["xml"] = new HTTPXMLService (new FileCache(WEB_CACHE_ROOT),true);

}
HTTPService * HTTPServiceManager::getService (string p_resource)
{
    string ext = p_resource.substr(p_resource.find_last_of(".") + 1);
    if ( services[ext]==NULL)
    {
        string base_name = p_resource.substr(p_resource.find_last_of("/") + 1);
        if ( services[base_name]==NULL) throw (HTTPNotAcceptableExceptionHandler());
        else return services[base_name]->clone(); 
    }
    else return services[ext]->clone(); 
}

HTTPServiceManager::~HTTPServiceManager()
{
    for_each (services.begin(),services.end(),[](const std::pair<string,HTTPService *>& it) -> bool {
        HTTPService * httpService = std::get<1>(it);
        delete(httpService);
        return true;
   });
}
