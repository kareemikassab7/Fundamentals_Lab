#ifndef HTTPVIDSERVICE_H
#define HTTPVIDSERVICE_H
#include "HTTPService.h"
class HTTPVIDService: public HTTPService
{
    private:
    public:
        HTTPVIDService(FileCache * p_fileCache,bool p_clean_cache = true);
        virtual bool execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket);
        virtual HTTPService * clone ();
        ~HTTPVIDService();
};

#endif 
