#include "HTTPRequest.h" 
static inline void ltrim(std::string &s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(),
            std::not1(std::ptr_fun<int, int>(std::isspace))));
}

static inline void rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(),
            std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
}

static inline void trim(std::string &s) {
    ltrim(s);
    rtrim(s);
}

void HTTPRequest::addToHeaderMap(string header_item)
{
    stringstream iss(header_item); 
    string key="";
    string value = ""; 
    getline(iss,key,':'); 
    getline(iss,value,'\r'); 
    trim(value);
    header[key] = value; 
}

HTTPRequest::HTTPRequest(TCPSocket * p_tcpSocket)
{
    tcpSocket = p_tcpSocket; 
}


void HTTPRequest::readAndParse(string initial_header)
{
    char buffer[1024];
    memset (buffer,1024,0);
    string http_stream=initial_header; 
    for ( ;http_stream.find("\r\n\r\n") ==std::string::npos; )
    { 
        tcpSocket->readFromSocket(buffer,1023);
        http_stream +=buffer;
        memset (buffer,0,1024);
    }
    stringstream iss(http_stream); 
    getline(iss,method,' '); 
    getline(iss,resource,' ');
    getline(iss,protocol,'\n');
    protocol.pop_back();

    string line = " ";
    for (;!line.empty();)
    {
        getline(iss,line,'\n');
        line.pop_back(); 
        if ( !line.empty()) addToHeaderMap(line); 
    }
    getline(iss,line,'\n'); 
    body = line;

}
string HTTPRequest::getResource ()
{
    return resource;
}

string HTTPRequest::getHeaderValue(string header_item_name)
{
    return header[header_item_name];
}

string & HTTPRequest::getBody()
{
    return body;
}
HTTPRequest::~HTTPRequest(){}
