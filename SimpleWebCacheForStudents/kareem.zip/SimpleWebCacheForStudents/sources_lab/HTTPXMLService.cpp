#include "HTTPXMLService.h"
#include "HTTPResponseHeader.h"
#include "HTTPNotFoundExceptionHandler.h"

HTTPXMLService::HTTPXMLService(FileCache * p_fileCache,bool p_clean_cache )
        :HTTPService(p_fileCache,p_clean_cache) {} 
bool HTTPXMLService::execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket)
{
    try { 
        string resource = p_httpRequest->getResource();
        FileCacheItem * fileCacheItem = fileCache->getFile(resource); 
        fileCacheItem = fileCacheItem->fetchContent();
        struct tm tm;
        string s = p_httpRequest->getHeaderValue("If-Modified-Since");
       
        HTTPResponseHeader * httpResponseHeader = new HTTPResponseHeader(p_tcpSocket,"OK",200,"HTTP/1.1");
        httpResponseHeader->setHeader("Content-Type","application/xml"); 
        httpResponseHeader->setHeader("Last-Modified",fileCacheItem->getLastUpdateTime());
        httpResponseHeader->setHeader("Connection","close");
        httpResponseHeader->setHeader("Content-Length",to_string(fileCacheItem->getSize()));
        
        httpResponseHeader->respond();
       
        p_tcpSocket->writeToSocket(fileCacheItem->getStream(),fileCacheItem->getSize());
       
        delete (httpResponseHeader);
        delete (fileCacheItem);
        return true;
    } 
    catch (HTTPNotFoundExceptionHandler httpNotFoundExceptionHandler)
    { 
        httpNotFoundExceptionHandler.handle(p_tcpSocket); 
        return false;
    }
}
HTTPService * HTTPXMLService::clone ()
{
    return new HTTPXMLService(fileCache,false);  
}
HTTPXMLService::~HTTPXMLService() 
{
}
