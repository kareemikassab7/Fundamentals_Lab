#include "GarbageCollector.h"

GarbageCollector::GarbageCollector(){ }//constructor
// Add a new HTTPTransaction object pointers
void GarbageCollector::addHTTPTransaction(HTTPTransaction * p_httpTransaction) {
    http_transaction_store.push_back(p_httpTransaction);
}// Clean up all finished threads
void GarbageCollector::cleanup() {
	// Loop to clean up all expired HTTP Transactions
    for (int i = 0 ; i < http_transaction_store.size(); )
    {
        if ( !http_transaction_store[i]->isRunning()) 
        {// If the HTTP Transaction is not runnings
            http_transaction_store[i]->waitForRunToFinish();
            HTTPTransaction * httpTransaction = http_transaction_store[i]; 
            delete (httpTransaction); //delete object
            http_transaction_store.erase(http_transaction_store.begin()+i);
        }
        else i++; // only increment if the HTTP Transaction is still running
    }
}// Invoked upon program termination to Gracefully wait for all running threads to finish
void GarbageCollector::terminate() {
	// Loop to clean up all HTTP Transactions, and pause/wait for running ones until they finish
    for ( ; http_transaction_store.size() > 0; )
    {
            http_transaction_store[0]->waitForRunToFinish();// wait for thread to finish
            HTTPTransaction * httpTransaction = http_transaction_store[0]; //fetch pointer to object
            delete (httpTransaction);// delete object
            http_transaction_store.erase(http_transaction_store.begin()); // erase the entry from the vector
    }
}
GarbageCollector::~GarbageCollector()//destructor
{
    terminate(); //call terminate
}

