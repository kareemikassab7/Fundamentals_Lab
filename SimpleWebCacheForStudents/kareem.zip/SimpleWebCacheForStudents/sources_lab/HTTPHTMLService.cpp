#include "HTTPHTMLService.h"
#include "HTTPResponseHeader.h"
#include "HTTPNotFoundExceptionHandler.h"
//constructor
HTTPHTMLService::HTTPHTMLService(FileCache * p_fileCache,bool p_clean_cache )
        :HTTPService(p_fileCache,p_clean_cache) {} 
bool HTTPHTMLService::execute(HTTPRequest * p_httpRequest,TCPSocket * p_tcpSocket)
{
    try { 
        string resource = p_httpRequest->getResource();//get the resource in the request
        FileCacheItem * fileCacheItem = fileCache->getFile(resource); //get the file of the resource
        fileCacheItem = fileCacheItem->fetchContent();// fetch content
        struct tm tm;//create struct
        string s = p_httpRequest->getHeaderValue("If-Modified-Since");//check the header value
        HTTPResponseHeader * httpResponseHeader = new HTTPResponseHeader(p_tcpSocket,"OK",200,"HTTP/1.1");// new object
        httpResponseHeader->setHeader("Content-Type","text/html"); // type:text
        httpResponseHeader->setHeader("Last-Modified",fileCacheItem->getLastUpdateTime());
        httpResponseHeader->setHeader("Connection","close");//close connection after responding
        httpResponseHeader->setHeader("Content-Length",to_string(fileCacheItem->getSize()));
        httpResponseHeader->respond();//respond
        p_tcpSocket->writeToSocket(fileCacheItem->getStream(),fileCacheItem->getSize());
        delete (httpResponseHeader);//delete object
        delete (fileCacheItem);//delete object
        return true;//return
    } // detect NotFoundExceptionHandler
    catch (HTTPNotFoundExceptionHandler httpNotFoundExceptionHandler)
    { 
        httpNotFoundExceptionHandler.handle(p_tcpSocket); 
        return false;
    }
}//cloner function
HTTPService * HTTPHTMLService::clone ()
{
    return new HTTPHTMLService(fileCache,false);  //return
}
HTTPHTMLService::~HTTPHTMLService() 
{//destructor
}
