#include "FileCacheItem.h"
#include "HTTPNotFoundExceptionHandler.h"
#include <sys/stat.h>

// Load file content of the target file
void FileCacheItem::load ()
{
    FILE * f = fopen (file_name.c_str(),"r");//open file
    // Failed to open file, throw an exception
    if ( f ==NULL) throw(HTTPNotFoundExceptionHandler());
    fseek(f,0,2);//seek end of file
    cache_item_size = ftell(f); //get size by following current
    fseek(f,0,0);//seek start of opened file
    if ( cache_item_stream != NULL) free (cache_item_stream);// Free the cache_item_stream buffer if already allocated
    cache_item_stream = (char *) calloc(cache_item_size,sizeof(char));//// Allocate buffer for the file content
    fread (cache_item_stream,1,cache_item_size,f);//read all the file
    stat(file_name.c_str(), &cache_item_stat);// record status
    fclose(f);
}
FileCacheItem::FileCacheItem()
{
    file_name = "";//set file name 
    cache_item_stream = NULL; // Set cache_item_stream to NULL
}
// Parameterized Constructor
FileCacheItem::FileCacheItem(string p_file_name)
{
    file_name = p_file_name;// assign value of parameter to variable 
    cache_item_stream = NULL; 
    load(); //load
}
FileCacheItem * FileCacheItem::fetchContent()
{// Create another FileCacheItem with the latest content of the target file. This is done to be able to decouple the main object in the cache from instances that is returned to the service engines
    fetch_mutex.lock();
    try{// Try executing the following code block looking from exceptions thrown
        struct stat attrib;// A file attribute structure
        if (stat(file_name.c_str(), &attrib) == -1)//// Could not fetch file attribute
        {
            fetch_mutex.unlock();//unlock
            throw(HTTPNotFoundExceptionHandler());//throw handler
        }
        if ( attrib.st_mtime != cache_item_stat.st_mtime ) load(); // Check if file modified since the last load
        FileCacheItem * fileCacheItem = new FileCacheItem();//create new cache item
        *fileCacheItem = *this; 
        fetch_mutex.unlock(); //unlock
        return fileCacheItem; //return pointer
    }catch (HTTPNotFoundExceptionHandler httpNotFoundExceptionHandler)
    { 
            fetch_mutex.unlock(); //unlock
            throw(httpNotFoundExceptionHandler); //throw handler
            return NULL;// return
    }
}

char * FileCacheItem::getLastUpdateTime ()// Return a pointer to the time_string representing the last update date/time
{
    memset (time_string,0,100); 
    struct tm tm = *gmtime(((time_t *) &cache_item_stat.st_mtime));
    strftime(time_string, 100, "%a, %d %b %Y %H:%M:%S %Z", &tm);
    return time_string; 
}
char * FileCacheItem::getStream()
{
	// Return a pointer to the current stream
    return cache_item_stream; // return a pointer to the cache buffer
}
long FileCacheItem::getSize()/// Return the cache buffer size
{
    return cache_item_size; //return cache buffer size
}

void FileCacheItem::operator=(const FileCacheItem & p_fileCacheItem)
{
    assign_mutex.lock();
    if ( cache_item_stream != NULL) free (cache_item_stream);
    cache_item_stream = (char *) calloc(p_fileCacheItem.cache_item_size,sizeof(char));
    cache_item_size=p_fileCacheItem.cache_item_size;
    cache_item_stat = p_fileCacheItem.cache_item_stat;
    memcpy (cache_item_stream,p_fileCacheItem.cache_item_stream,cache_item_size);
    assign_mutex.unlock(); 
}

FileCacheItem::~FileCacheItem()//destructor
{
    if ( cache_item_stream != NULL ) free (cache_item_stream);// If cache_item_stream buffer is allocated free it.
   
}
