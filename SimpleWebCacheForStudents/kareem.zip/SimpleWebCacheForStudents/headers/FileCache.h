#ifndef FILECACHE_H
#define FILECACHE_H
#include "FileCacheItem.h"

class FileCache
{
    private:
        std::map <string,FileCacheItem *> cache;
        string root;
    public:
        FileCache(string p_root); 
        FileCacheItem * getFile(string p_file_name);
        ~FileCache (); 
};

#endif
